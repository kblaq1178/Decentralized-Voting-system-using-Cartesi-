class Proposal {
    constructor(title, description) {
        this.id = Date.now().toString(); // Simplified ID generation
        this.title = title;
        this.description = description;
    }
}

module.exports = Proposal;
