class Voter {
    constructor(name, id) {
        this.id = id;
        this.name = name;
    }
}

module.exports = Voter;
