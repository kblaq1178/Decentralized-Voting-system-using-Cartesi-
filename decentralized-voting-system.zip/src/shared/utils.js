// Utils for input validation and other helper functions

exports.isValidProposal = (title, description) => {
    return title && title.trim() !== '' && description && description.trim() !== '';
};

exports.isValidVoter = (name, id) => {
    return name && name.trim() !== '' && id && id.trim() !== '';
};

exports.isValidVote = (voterId, proposalId, vote) => {
    return voterId && voterId.trim() !== '' && proposalId && proposalId.trim() !== '' && typeof vote === 'boolean';
};

// Add other utility functions as needed
